package com.green.java.ch01;

public class Naming {
    public static void main(String[] args){

        // 기법

        // 파스칼 케이스 기법
        //  String HelloWorldBye();
        // 카멜 케이스 기법 변수명, 메소드명
        //  String helloWorldBye();
        // 가장 많이 쓰임
        // 스네이크 케이스 기법
        //String _hello_world_bye();
        // 케밥 케이스 기법
        //String -hello-world-byte();

        // 자바에서 쓸수있는 특수기호 2개 : _ , $
        // 이름 처음에 숫자 사용할수없다 , 처음만 아니면 사용가능
        // 이름에 빈칸 사용할수없다
        // 대소문자 구분도니다
        // 예약어(파란색) 사용불가



        //String _hello;
        //        String $hello;

        //
    }
}
