package com.green.java.ch02;

public class VariableBoolean {
    public static void main(String[] arg){
        boolean b1 = true;
        boolean b2 = false;
        System.out.println(b1);
        System.out.println(b2);

        b2 = (10 > 2);
        System.out.println(b2);
    }
}
