package com.green.java.ch02;

public class VariableNumber {
    public static void main(String[] args) {

        System.out.println("\n");

        byte b1;
        short s1;
        long l1; // 8byte
        // int > 4byte , 가장 빠르다
        int n1; // 선언

        n1 = 10; // 할당

        System.out.println(n1);

        n1 = 20;

        System.out.println(n1);
    }
}
