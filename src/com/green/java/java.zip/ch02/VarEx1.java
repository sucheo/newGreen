package com.green.java.ch02;
//21p

public class VarEx1 {
    public static void main(String[] args){
        int year = 0;
        int age = 14;

        System.out.println(year);
        System.out.println(age);

        year = age + 2000;
        age = age +1;

        System.out.println(year);
        System.out.println(age);

    }
}
