package com.green.java.ch02;

public class VariableChar {
    public static void main(String[] args){

        char c1 = 'A'; // char 문자, ' ' 사용
        System.out.println(c1);

        c1 = '한';
        System.out.println(c1);
        c1 = 'B';
        System.out.printf("%c : %d  \n", c1, (int)c1);
    }
}
