package com.green.java.ch02;

public class CastingEx2 {
    public static void main(String[] args){
        int n1 = 10;
        int n2 = 3;
        double account = (double)n1/n2;
        System.out.print(account);
    }
}
